<?php
// Silence is golden.
// This file prevents directory browsing
?>