<?php

/**
 * Contact Form Widget for Elementor - FIXED VERSION
 * Generates nonces dynamically to prevent caching issues
 */

namespace MoneybagPlugin\Widgets;

if (!defined('ABSPATH')) {
    exit;
}

class Contact_Form_Widget extends \Elementor\Widget_Base
{

    /**
     * Get widget name
     */
    public function get_name()
    {
        return 'moneybag-contact-form';
    }

    /**
     * Get widget title
     */
    public function get_title()
    {
        return __('Moneybag Contact Form', 'moneybag-plugin');
    }

    /**
     * Get widget icon
     */
    public function get_icon()
    {
        return 'eicon-form-horizontal';
    }

    /**
     * Get widget categories
     */
    public function get_categories()
    {
        return ['moneybag'];
    }

    /**
     * Register widget controls
     */
    protected function register_controls()
    {
        // No controls as per v2.0.0 architecture
    }

    /**
     * Render widget output on the frontend
     */
    protected function render()
    {
        $widget_id = $this->get_id();

        // Get reCAPTCHA site key from options
        $recaptcha_site_key = get_option('moneybag_recaptcha_site_key', '');

        // FIXED: Do NOT include nonce in config - it will be fetched dynamically
        $config = [
            'recaptcha_site_key' => $recaptcha_site_key
        ];

?>
        <div id="moneybag-contact-form-<?php echo esc_attr($widget_id); ?>" class="moneybag-form contact-form-container">
        </div>

        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                if (typeof wp !== 'undefined' && wp.element && window.MoneybagContactForm) {
                    const {
                        render
                    } = wp.element;
                    const container = document.getElementById('moneybag-contact-form-<?php echo esc_js($widget_id); ?>');

                    if (container) {
                        render(
                            wp.element.createElement(window.MoneybagContactForm, {
                                ajaxUrl: '<?php echo esc_js(admin_url('admin-ajax.php')); ?>',
                                // FIXED: Remove hardcoded nonce - will be fetched dynamically
                                widgetId: '<?php echo esc_js($widget_id); ?>',
                                config: <?php echo json_encode($config); ?>
                            }),
                            container
                        );
                    }
                }
            });
        </script>
    <?php
    }

    /**
     * Render widget output in the editor
     */
    protected function content_template()
    {
    ?>
        <div class="moneybag-form contact-form-container">
            <div class="elementor-alert elementor-alert-info">
                Contact Form Widget - Form will be displayed on the frontend
            </div>
        </div>
<?php
    }
}
